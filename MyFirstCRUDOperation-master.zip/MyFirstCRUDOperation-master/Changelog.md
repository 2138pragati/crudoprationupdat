# Changelog

## [0.0.2] - 07-08-2025
### Added
    - Added a welcome message
----

## [0.0.1] - 07-08-2025
### Added
    - APIs for CRUD operations of Developer entity
    - getById, getAll , deleteById,updatedeveloper